"""
Iris Project — Model Training
------------------------------
Follows the repo's notebooks:
  • load_iris_gridseach.ipynb → GridSearchCV (KNN + SVC), final SVC classifier
  • k_means.ipynb             → KMeans clustering on petal features

Trains & evaluates several classifiers, saves the notebook-style SVC model
(with probabilities), metrics, and charts used by the web demo.

Run:  python3 train_model.py
"""

import json
import os
import warnings

warnings.filterwarnings("ignore")

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.datasets import load_iris
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)
os.makedirs("model", exist_ok=True)
os.makedirs("charts", exist_ok=True)

sns.set_style("darkgrid")
plt.rcParams.update({"figure.facecolor": "#141a26", "axes.facecolor": "#141a26",
                     "axes.edgecolor": "#2a3345", "axes.labelcolor": "#c8d0dc",
                     "xtick.color": "#8a93a5", "ytick.color": "#8a93a5",
                     "text.color": "#e8e8ea", "savefig.facecolor": "#141a26"})

# ------------------------------------------------------------------
# 1) Load the dataset (load_iris as in both notebooks)
# ------------------------------------------------------------------
iris = load_iris(as_frame=True)
df = iris.frame
X = df.drop("target", axis=1)
y = df["target"]
CLASS_NAMES = list(iris.target_names)
FEATURES = list(X.columns)
print(f"Iris dataset: {df.shape[0]} samples, features={FEATURES}")

# 2) Train/test split (same as the notebook: 0.2, random_state=42)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# ------------------------------------------------------------------
# 3) GridSearchCV — exactly the two searches from the notebook
# ------------------------------------------------------------------
print("Running GridSearchCV (as in load_iris_gridseach.ipynb)…")

knn = KNeighborsClassifier()
knn_params = {"n_neighbors": [3, 5, 7, 9], "p": [1, 2]}
knn_gs = GridSearchCV(knn, knn_params, cv=5).fit(X_train, y_train)
knn_best = knn_gs.best_estimator_
print(f"  KNN best: {knn_gs.best_params_}")

svc = SVC()
svc_params = {"kernel": ["linear", "poly", "rbf", "sigmoid"], "degree": [3, 4, 5]}
svc_gs = GridSearchCV(svc, svc_params, cv=5).fit(X_train, y_train)
print(f"  SVC best: {svc_gs.best_params_}")

# Final model = the notebook's final_SVC, with probabilities for the UI
final_svc = SVC(kernel=svc_gs.best_params_["kernel"],
                degree=svc_gs.best_params_["degree"], probability=True)
final_svc.fit(X_train, y_train)

# 4) Compare multiple classifiers (README future improvement ✅)
candidates = {
    "KNN (GridSearchCV)": knn_best,
    "SVM / SVC (GridSearchCV)": final_svc,
    "Decision Tree": DecisionTreeClassifier(random_state=42).fit(X_train, y_train),
    "Random Forest": RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train, y_train),
}
results = {}
for name, m in candidates.items():
    acc = float(accuracy_score(y_test, m.predict(X_test)))
    results[name] = {"test_accuracy": round(acc, 4)}
    print(f"  {name:<26} test accuracy = {acc:.3f}")

best_name = max(results, key=lambda k: results[k]["test_accuracy"])
print(f"Best on test: {best_name}")

cm = confusion_matrix(y_test, final_svc.predict(X_test))

# ------------------------------------------------------------------
# 5) Charts
# ------------------------------------------------------------------
print("Generating charts…")

# 5a) Confusion matrix of the notebook's final SVC
fig, ax = plt.subplots(figsize=(5.2, 4.2))
sns.heatmap(cm, annot=True, fmt="d", cmap="mako", cbar=False,
            xticklabels=CLASS_NAMES, yticklabels=CLASS_NAMES,
            annot_kws={"size": 13}, ax=ax, linewidths=1, linecolor="#141a26")
ax.set_xlabel("Predicted", color="#c8d0dc")
ax.set_ylabel("Actual", color="#c8d0dc")
ax.set_title("SVC Confusion Matrix (test set)", fontsize=12, color="#f5c518", pad=10)
plt.tight_layout()
plt.savefig("charts/confusion.png", dpi=110)
plt.close()

# 5b) Decision boundary on petal length/width (2D view)
pl, pw = X.columns.get_loc("petal length (cm)"), X.columns.get_loc("petal width (cm)")
X2 = X.iloc[:, [pl, pw]].values
svc2 = SVC(kernel=svc_gs.best_params_["kernel"],
           degree=svc_gs.best_params_["degree"]).fit(X2, y)
xx, yy = np.meshgrid(
    np.linspace(X2[:, 0].min() - 0.5, X2[:, 0].max() + 0.5, 300),
    np.linspace(X2[:, 1].min() - 0.3, X2[:, 1].max() + 0.3, 300),
)
Z = svc2.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)
fig, ax = plt.subplots(figsize=(6.8, 4.4))
ax.contourf(xx, yy, Z, alpha=0.35, levels=[-0.5, 0.5, 1.5, 2.5],
            colors=["#2dd4bf", "#f5c518", "#f472b6"])
scatter = ax.scatter(X2[:, 0], X2[:, 1], c=y, cmap="viridis", s=22,
                     edgecolors="#0d1117", linewidths=0.4)
ax.set_xlabel("petal length (cm)")
ax.set_ylabel("petal width (cm)")
handles, _ = scatter.legend_elements()
ax.legend(handles, CLASS_NAMES, fontsize=8, facecolor="#141a26",
          edgecolor="#2a3345", labelcolor="#e8e8ea")
ax.set_title("SVC Decision Regions (petal features)", fontsize=12, color="#f5c518", pad=10)
plt.tight_layout()
plt.savefig("charts/boundary.png", dpi=110)
plt.close()

# 5c) KMeans elbow chart (k_means.ipynb cell 1)
Xkm = X.iloc[:, [pl, pw]].values  # petal length & width like the notebook
inertia = []
ks = range(1, 10)
for k in ks:
    inertia.append(KMeans(n_clusters=k, random_state=42, n_init=10).fit(Xkm).inertia_)
fig, ax = plt.subplots(figsize=(6.4, 3.8))
ax.plot(list(ks), inertia, marker="o", color="#f5c518")
ax.axvline(3, color="#34d399", ls="--", alpha=0.7)
ax.annotate("elbow → k=3", (3, inertia[2]), xytext=(4.2, inertia[2] + 40),
            color="#34d399", fontsize=10)
ax.set_xlabel("k (number of clusters)")
ax.set_ylabel("Inertia")
ax.set_title("Elbow Method — KMeans", fontsize=12, color="#f5c518", pad=10)
plt.tight_layout()
plt.savefig("charts/elbow.png", dpi=110)
plt.close()

# ------------------------------------------------------------------
# 6) Persist artifacts
# ------------------------------------------------------------------
joblib.dump(final_svc, "model/iris_svc.joblib")
with open("model/results.json", "w") as f:
    json.dump({
        "class_names": CLASS_NAMES,
        "features": FEATURES,
        "svc_best_params": {k: (str(v) if not isinstance(v, (int, float, str)) else v)
                             for k, v in svc_gs.best_params_.items()},
        "knn_best_params": {k: (str(v) if not isinstance(v, (int, float, str)) else v)
                             for k, v in knn_gs.best_params_.items()},
        "results": results,
        "best_name": best_name,
        "confusion_matrix": cm.tolist(),
    }, f, indent=2)
print("Saved: model/iris_svc.joblib, model/results.json, charts/*.png")
