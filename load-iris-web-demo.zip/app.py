"""
🌸 Iris Project — Web Demo
---------------------------
Deployed version of the two notebooks in this repo:
  • load_iris_gridseach.ipynb → species classifier (GridSearchCV → SVC)
  • k_means.ipynb             → KMeans clustering explorer

Run:  python3 app.py   →  open http://localhost:8002
"""

import base64
import io
import json
import os

BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)

import joblib
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.datasets import load_iris

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

model = joblib.load("model/iris_svc.joblib")
with open("model/results.json") as f:
    RESULTS = json.load(f)
CLASS_NAMES = RESULTS["class_names"]
FEATURES = RESULTS["features"]

# Iris dataset (same as the notebooks) for the KMeans explorer
iris = load_iris(as_frame=True)
KMEANS_X = iris.frame[["petal length (cm)", "petal width (cm)"]].values


def chart_b64(name):
    path = os.path.join("charts", name)
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        return "data:image/png;base64," + base64.b64encode(f.read()).decode()


CHARTS = {"boundary": chart_b64("boundary.png"),
          "confusion": chart_b64("confusion.png"),
          "elbow": chart_b64("elbow.png")}

# Slider metadata: [min, max, step, default, label]
SLIDERS = {
    "sepal length (cm)": [4.3, 7.9, 0.1, 5.8, "Sepal Length"],
    "sepal width (cm)":  [2.0, 4.4, 0.1, 3.0, "Sepal Width"],
    "petal length (cm)": [1.0, 6.9, 0.1, 4.3, "Petal Length"],
    "petal width (cm)":  [0.1, 2.5, 0.1, 1.3, "Petal Width"],
}

PRESETS = {
    "🌸 Setosa typical":     [5.1, 3.5, 1.4, 0.2],
    "🌼 Versicolor typical": [5.9, 3.0, 4.2, 1.3],
    "🌺 Virginica typical":  [6.5, 3.0, 5.5, 2.0],
}

CLS_COLORS = ["#2dd4bf", "#f5c518", "#f472b6"]

_km_cache = {}


def kmeans_plot_b64(k):
    """Live KMeans on petal features — exactly like k_means.ipynb."""
    if k in _km_cache:
        return _km_cache[k]
    km = KMeans(n_clusters=k, random_state=42, n_init=10).fit(KMEANS_X)
    fig, ax = plt.subplots(figsize=(6.4, 4.0))
    sns.set_style("darkgrid")
    plt.rcParams.update({"figure.facecolor": "#141a26", "axes.facecolor": "#141a26",
                         "axes.edgecolor": "#2a3345", "axes.labelcolor": "#c8d0dc",
                         "xtick.color": "#8a93a5", "ytick.color": "#8a93a5",
                         "savefig.facecolor": "#141a26"})
    ax.scatter(KMEANS_X[:, 0], KMEANS_X[:, 1], c=km.labels_, cmap="viridis", s=30,
               edgecolors="#0d1117", linewidths=0.4)
    ax.scatter(km.cluster_centers_[:, 0], km.cluster_centers_[:, 1],
               c="red", marker="X", s=220, label="Centroids",
               edgecolors="white", linewidths=1.2)
    ax.set_xlabel("petal length (cm)")
    ax.set_ylabel("petal width (cm)")
    ax.set_title(f"KMeans clustering — k = {k}", fontsize=12, color="#f5c518", pad=10)
    ax.legend(fontsize=9, facecolor="#141a26", edgecolor="#2a3345", labelcolor="#e8e8ea")
    buf = io.BytesIO()
    plt.tight_layout()
    plt.savefig(buf, format="png", dpi=110)
    plt.close()
    b64 = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()
    _km_cache[k] = b64
    return b64


# ------------------------------------------------------------------
# Routes
# ------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html", sliders=SLIDERS, presets=PRESETS,
                           results=RESULTS, charts=CHARTS,
                           colors=CLS_COLORS)


@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True) or {}
    feats = data.get("features")
    try:
        row = []
        if isinstance(feats, list):
            # UI sends a plain list of the 4 values
            for i, f in enumerate(FEATURES):
                v = float(feats[i]) if i < len(feats) else SLIDERS[f][3]
                lo, hi = SLIDERS[f][0], SLIDERS[f][1]
                row.append(max(lo, min(hi, v)))
        else:
            feats = feats or {}
            for f in FEATURES:
                v = float(feats.get(f, SLIDERS[f][3]))
                lo, hi = SLIDERS[f][0], SLIDERS[f][1]
                row.append(max(lo, min(hi, v)))
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid feature values"}), 400

    proba = model.predict_proba([row])[0]
    idx = int(np.argmax(proba))
    return jsonify({
        "species": CLASS_NAMES[idx].capitalize(),
        "class_index": idx,
        "probabilities": [{"name": CLASS_NAMES[i].capitalize(),
                           "p": round(float(p), 4)}
                          for i, p in enumerate(proba)],
        "model": "SVC (GridSearchCV: kernel=linear, degree=3)",
    })


@app.route("/api/kmeans")
def kmeans_api():
    try:
        k = int(request.args.get("k", 3))
    except ValueError:
        k = 3
    k = max(1, min(9, k))
    km = KMeans(n_clusters=k, random_state=42, n_init=10).fit(KMEANS_X)
    return jsonify({"image": kmeans_plot_b64(k), "inertia": round(float(km.inertia_), 1), "k": k})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8002, threaded=True)
